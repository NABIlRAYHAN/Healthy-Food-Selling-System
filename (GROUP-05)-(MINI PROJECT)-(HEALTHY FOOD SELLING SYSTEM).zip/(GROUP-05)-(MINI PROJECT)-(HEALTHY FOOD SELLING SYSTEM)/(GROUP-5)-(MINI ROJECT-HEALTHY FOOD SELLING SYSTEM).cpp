//Group:05
//Member's Name
//Nabil Rayhan-A20EC9107
//Nazmus Sakib-A20EC4046
//Fariduzzaman-A20EC4016
//Nazmul Alam khan-A20EC4045


#include <iostream>
#include <fstream>

using namespace std;
int i = 0;

class foodShop
{
private:
    string item, features;
    int stock;
    double price;

public:
    foodShop()
    {
        item = features = "";
        stock = 0;
        price = 0.0;
    }

    foodShop(string m, string f, int s, double p)
    {
        item = m;
        features = f;
        stock = s;
        price = p;
    }

    void showFood()
    {
        cout << "item : " << item << endl;
        cout << "Features : " << features << endl;
        cout << "Stock : " << stock << endl;
        cout << "Price : " << price << endl;
    }

    string getitem()
    {
        return item;
    }

    void updateStock(int upd)
    {
        stock += upd;
    }

    int getStock()
    {
        return stock;
    }

    double getPrice()
    {
        return price;
    }
    string getFeatures()
    {
        return features;
    }
};

class Node
{
public:
    foodShop *element;
    Node *next;
    Node *prev;
    Node(foodShop *e, Node *n, Node *p)
    {
        element = e;
        next = n;
        prev = p;
    }
};

class list
{
public:
    foodShop *f = new foodShop();
    Node *head = new Node(f, NULL, NULL);
    list()
    {
        head->next = head->prev = head;
    }
    void showList()
    {
        Node *n = head->next;
        while (n != head)
        {
            n->element->showFood();
            n = n->next;
        }
        cout << endl;
    }
    int countNode()
    {
        int c = 0;
        Node *n = head->next;
        while (n != head)
        {
            c++;
            n = n->next;
        }
        return c;
    }
    void insert(Node *newElement)
    {

        Node *n = newElement;
        head->prev->next = n;
        n->prev = head->prev;
        head->prev = n;
        n->next = head;
    }
    void insert(foodShop *newElement, int index)
    {
        int size = countNode();
        if (index < 0 or index >= size)
        {
            cout << "invalid index";
            return;
        }
        Node *m = head->next;
        while (m != head)
        {
            if (m->element == newElement)
            {
                cout << "key already exists";
                return;
            }
            m = m->next;
        }
        int i = 0;
        Node *nw = new Node(newElement, NULL, NULL);
        Node *n = head->next;
        while (n != head)
        {
            if (i == index)
            {
                n->prev->next = nw;
                nw->prev = n->prev;
                n->prev = nw;
                nw->next = n;
                return;
            }
            i++;
            n = n->next;
        }
    }
    void remove(int index)
    {
        int size = countNode();
        if (index < 0 or index >= size)
        {
            cout << "invalid index";
            return;
        }
        Node *n = head->next;
        int i = 0;
        while (n != head)
        {
            if (i == index)
            {
                Node *p = n->prev;
                Node *q = n->next;
                p->next = q;
                q->prev = p;
                n->next = n->prev = NULL;
                return;
            }
            n = n->next;
            i++;
        }
    }

    void sort()
    {
        for (Node *i = head->prev; i != head; i = i->prev)
        {
            // Node* n=new Node(NULL,NULL,NULL);
            for (Node *j = head->next; j != i; j = j->next)
            {
                if (j->element->getPrice() > j->next->element->getPrice())
                {
                    swap(j->element, j->next->element);
                }
            }
        }
    }
};

class owner
{
public:
    owner(list obj, int n)
    {
        int newStock, swt;
        foodShop *l = new foodShop();

        while (1)
        {
            cout << "--Owner menu--\nselect one from below\n";
            cout << "1: Sort the food based on price\n2: Check Stock\n3: Receive Stock\n4: Print details\n5: exit\n"
                 << endl;
            cin >> swt;
            cout << endl;

            if (swt == 1)
                obj.sort();
            else if (swt == 2)
                orderfood(obj, 10, l, newStock);
            else if (swt == 3)
                recieveStock(obj, 10, l, newStock);
            else if (swt == 4)
                print(obj, 10);
            else if (swt == 5)
                break;
            else
                cout << "Invalid Selection.." << endl;
        }
    }

    void orderfood(list obj, int n, foodShop *l, int &newStock)
    {
        for (Node *j = obj.head->next; j != obj.head; j = j->next)
        {
            if (j->element->getStock() < 10)
            {
                string m = j->element->getitem();
                cout << "Your Stock for " << m << " is less than 10" << endl;
                cout << "Enter new Stock For: " << m << endl;
                cin >> newStock;
                l = j->element;
                break;
            }
        }
        l->updateStock(newStock);
        cout << "stock updated" << endl
             << endl;
    }

    void recieveStock(list obj, int n, foodShop *l, int &newStock)
    {
        string m = l->getitem();
        cout << "You added " << newStock << " pieces of " << m << endl;
        cout << "New stock is " << l->getStock() << endl
             << endl;
    }

    void print(list obj, int n)
    {
        // obj.showList();
        string item;
        cout << "Enter name of food: ";
        cin >> item;
        // int j;
        Node *j = obj.head->next;
        for (; j != obj.head; j = j->next)
            if (item == j->element->getitem())
                break;
        j->element->showFood();
        cout << endl;
    }
};

class customer
{
public:
    customer(list obj, int n)
    {
        int swt;
        string customerName;
        foodShop *boughtIndex = new foodShop();

        while (1)
        {
            cout << "--Customer menu--\nselect one from below\n";
            cout << "1: Search food\n2: Buy food\n3: Get Receipt\n4: exit\n";
            cin >> swt;
            cout << endl;
            if (swt == 1)
                search(obj, 10);
            else if (swt == 2)
                boughtIndex = buyfood(obj, 10, customerName);
            else if (swt == 3)
                getReciept(obj, 10, customerName, boughtIndex);
            else if (swt == 4)
                break;
            else
                cout << "Invalid Selection" << endl;
        }
    }
    void search(list obj, int n)
    {
        cout << "Based on\n1: name\n2: feature\n3: Price\n";
        int choice;
        cin >> choice;
        if (choice == 1)
        {
            string item;
            cout << "Enter name : ";
            cin >> item;

            for (Node *d = obj.head->next; d != obj.head; d = d->next)
            {
                if (item == d->element->getitem())
                {
                    d->element->showFood();
                    break;
                }
            }
            cout << "not found\n";
        }
        else if (choice == 2)
        {
            string feature;
            cout << "Enter exact features: ";
            cin >> feature;

            for (Node *d = obj.head->next; d != obj.head; d = d->next)
            {
                if (feature == d->element->getFeatures())
                {
                    d->element->showFood();
                    break;
                }
            }
        }
        else if (choice == 3)
        {
            double price;
            cout << "Enter Price: ";
            cin >> price;

            for (Node *d = obj.head->next; d != obj.head; d = d->next)
            {
                if (price == d->element->getPrice())
                {
                    d->element->showFood();
                    break;
                }
            }
        }
    }

    foodShop *buyfood(list obj, int n, string &customerName)
    {
        string item;
        cout << "Enter Customer Name: ";
        cin >> customerName;
        cout << "Enter name of food: ";
        cin >> item;
        for (Node *d = obj.head->next; d != obj.head; d = d->next)
        {
            if (item == d->element->getitem())
            {
                d->element->showFood();
                d->element->updateStock(-1);

                cout << "--purchase done--" << endl
                     << endl;
                return d->element;
                // return;
            }
        }
        foodShop *f = new foodShop();
        cout << "not found" << endl;
        return f;
    }

    void getReciept(list obj, int n, string &customerName, foodShop *boughtIndex)
    {
        cout << "Customer Name: " << customerName << endl;
        boughtIndex->showFood();
        cout << "Thank you for the purchase" << endl
             << endl;
    }
};

int main()
{
    // foodShop *obj[10];
    list obj;
    ifstream infile;
    infile.open("data.txt");
    string s1, s2, customerName = "";
    int stock, newStock = 0, l, swt, boughtIndex;
    double p;

    while (!infile.eof())
    {
        infile >> s1 >> stock >> p;
        getline(infile, s2);
        foodShop *f = new foodShop(s1, s2, stock, p);
        Node *n = new Node(f, NULL, NULL);
        obj.insert(n);
        i++;
    }
    // obj.showList();
    while (1)
    {
        cout << "Welcome to Healthy food Selling System." << endl;
        cout << "1: Shop Owner\n2: Customer.\n3: show menu\n4: exit\nSelect : ";
        int x;
        cin >> x;
        cout << endl;
        if (x == 1)
            owner o(obj, 10);
        else if (x == 2)
            customer c(obj, 10);
        else if (x == 3)
            obj.showList();
        else
            break;
    }
    return 0;
}
